// Check if users exist in local storage, if not, create an empty object
let users = JSON.parse(localStorage.getItem('users')) || {};

// Function to handle user login
function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const authMessage = document.getElementById("authMessage");

    if (users[username] && users[username] === password) {
        authMessage.textContent = '';
        document.getElementById("authSection").style.display = "none";
        document.getElementById("mainSection").style.display = "block";
        displayQuote();
    } else {
        authMessage.textContent = "Invalid username or password.";
    }
}

// Function to toggle between login and register
function toggleRegister() {
    const authSection = document.getElementById("authSection");
    const registerSection = document.getElementById("registerSection");

    authSection.style.display = authSection.style.display === "none" ? "block" : "none";
    registerSection.style.display = registerSection.style.display === "none" ? "block" : "none";
}

// Function to register a new user
function register() {
    const regUsername = document.getElementById("regUsername").value;
    const regPassword = document.getElementById("regPassword").value;
    const registerMessage = document.getElementById("registerMessage");

    if (regUsername && regPassword) {
        if (!users[regUsername]) {
            users[regUsername] = regPassword;
            localStorage.setItem('users', JSON.stringify(users));
            registerMessage.textContent = "User registered successfully!";
        } else {
            registerMessage.textContent = "Username already exists.";
        }
    } else {
        registerMessage.textContent = "Please fill in all fields.";
    }
}

// Function to save the daily purpose
function savePurpose() {
    const purposeInput = document.getElementById("dailyPurposeInput").value;
    if (purposeInput) {
        alert("Your purpose for today: " + purposeInput);
    } else {
        alert("Please enter a purpose.");
    }
}

// Function to add a new goal to the list
function addGoal() {
    const newGoal = document.getElementById("newGoal").value;
    if (newGoal) {
        const listItem = document.createElement("li");
        listItem.innerHTML = `<input type="checkbox"> ${newGoal}`;
        document.getElementById("goalsList").appendChild(listItem);
        document.getElementById("newGoal").value = ""; // Clear input field
    } else {
        alert("Please enter a goal.");
    }
}

// Function to add a new habit to the list
function addHabit() {
    const newHabit = document.getElementById("newHabit").value;
    if (newHabit) {
        const habitItem = document.createElement("li");
        habitItem.innerHTML = `<input type="checkbox"> ${newHabit}`;
        document.getElementById("habitsList").appendChild(habitItem);
        document.getElementById("newHabit").value = ""; // Clear input field
    } else {
        alert("Please enter a habit.");
    }
}

// Quotes for the app
const quotes = [
    "The best way to get started is to quit talking and begin doing.",
    "The pessimist sees difficulty in every opportunity. The optimist sees opportunity in every difficulty.",
    "Don’t let yesterday take up too much of today.",
    "It’s not whether you get knocked down, it’s whether you get up.",
    "People who are crazy enough to think they can change the world, are the ones who do."
];

// Function to display a random quote each morning
function displayQuote() {
    const quoteElement = document.getElementById("quote");
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    quoteElement.textContent = randomQuote;
}
